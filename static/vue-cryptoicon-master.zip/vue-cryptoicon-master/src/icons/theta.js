const Theta = {
  symbol: 'theta',
  color: '#000',
  plainIcon: c => {
    return `<path fill="${
      c ? c : this.color
    }" d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zM10.96 6l-.96.993v18.014l.96.993h10.08l.96-.993V6.993L21.04 6zm.96 18.013V7.987h8.16v16.026zm7.134-5.17v-1.948h-6.058v1.949h2.087v2.262h1.884v-2.262zm0-5.582h-2.087v-2.263h-1.884v2.263h-2.087v1.948h6.058z" fill-rule="evenodd"/>`;
  },
  colorIcon() {
    return `<g fill="none" fill-rule="evenodd"><circle cx="16" cy="16" fill="#2ab8e6" r="16"/><path d="M10.96 6h10.08l.96.993v18.014l-.96.993H10.96l-.96-.993V6.993zm.96 18.013h8.16V7.987h-8.16zm7.134-5.17h-2.087v2.263h-1.884v-2.262h-2.087v-1.949h6.058zm0-5.582v1.948h-6.058v-1.948h2.087v-2.263h1.884v2.263z" fill="#fff" fill-rule="nonzero"/></g>`;
  }
};
export default Theta;
